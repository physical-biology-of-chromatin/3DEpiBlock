'config.xyz': xyz coordinates of each sampled configurations (given in lattice unit, 1 lattice unit=sqrt(2)x nearest-neibor distance), one configuration after the other
'config.psf': psf file informing on the connectivity between monomers, to be used in VMD prior to load the .xyz file 
