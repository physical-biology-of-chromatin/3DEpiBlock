#####################################################################
# This script compiles and runs 3DEpiBlock.Energy (by Daniel Jost - daniel.jost@ens-lyon.fr)
# to run the program:
# 1) modify the simulation parameters
# 2) define the state of the monomers in '/input/state.out'
# 3) run the simulation by typing 'bash install-and-run.sh' in the terminal
#####################################################################

###################################################################
#       SIMULATION PARAMETERS
###################################################################

nchain=2000  #size of the chain
l=8 #size of the simulation box
niter=2 #number of iterations
nmeas=2 #number of snapshots per iteration
ninter=10000 #number of Monte-Carlo steps between two snapshots
kint=1.5 #bending energy (in kT)
nstate=4    #number of different states
ei=-0.1 # energy of interaction (in kT) between monomers of the same state occupying nearest-neighbor sites on the lattice

###################################################################
#       COMPILATION
###################################################################

t=$((4*${l}*${l}*${l}))
td=$((10*${nmeas}*${niter}))
sb=$((13+${nstate}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' ./src/input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' ./src/input.dat
sed -i.back -e '3c\'$'\n '$niter' ::Niter' ./src/input.dat
sed -i.back -e '4c\'$'\n '$nmeas' ::Nmeas' ./src/input.dat
sed -i.back -e '5c\'$'\n '$ninter' ::Ninter' ./src/input.dat
sed -i.back -e '6c\'$'\n '$kint' ::kint' ./src/input.dat
sed -i.back -e '7c\'$'\n '$nstate' ::Nstate' ./src/input.dat
sed -i.back -e '8c\'$'\n '$ei' ::Ei' ./src/input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' ./src/global.var
sed -i.back -e '4c\'$'\n integer,dimension('$sb','$t') ::bittable' ./src/global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr' ./src/global.var
sed -i.back -e '9c\'$'\n integer,dimension('$nchain') ::state' ./src/global.var



make clean
make

###################################################################
#       RUN
###################################################################
time ./bin/3depiblock.energy
make clean

