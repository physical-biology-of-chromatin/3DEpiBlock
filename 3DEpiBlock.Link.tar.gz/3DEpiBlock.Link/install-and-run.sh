#####################################################################
# This script compiles and runs 3DEpiBlock.Link (by Daniel Jost - daniel.jost@ens-lyon.fr)
# to run the program:
# 1) modify the simulation parameters
# 2) define the state of the monomers in '/input/state.out'
# 3) run the simulation by typing 'bash install-and-run.sh' in the terminal
#####################################################################

###################################################################
#       SIMULATION PARAMETERS
###################################################################

nchain=2000 #size of the chain
l=8 #size of the simulation box
niter=1 #number of iterations
nmeas=2   #number of snapshots per iteration
ninter=10000    #number of Monte-Carlo steps between two snapshots
kint=1.5    #bending energy (in kT)
kb=1e-4 #binding probability per MC step between monomers of the same state occupying nearest-neighbor sites on the lattice
ku=1e-3 #unbinding probability per MC step between linked monomers

###################################################################
#       COMPILATION
###################################################################

t=$((4*${l}*${l}*${l}))
td=$((10*${nmeas}*${niter}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' ./src/input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' ./src/input.dat
sed -i.back -e '3c\'$'\n '$niter' ::Niter' ./src/input.dat
sed -i.back -e '4c\'$'\n '$nmeas' ::Nmeas' ./src/input.dat
sed -i.back -e '5c\'$'\n '$ninter' ::Ninter' ./src/input.dat
sed -i.back -e '6c\'$'\n '$kint' ::kint' ./src/input.dat
sed -i.back -e '7c\'$'\n '$kb' ::kb' ./src/input.dat
sed -i.back -e '8c\'$'\n '$ku' ::ku' ./src/input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' ./src/global.var
sed -i.back -e '4c\'$'\n integer,dimension(15,'$t') ::bittable' ./src/global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr' ./src/global.var
sed -i.back -e '9c\'$'\n integer,dimension(2,'$nchain') ::contact' ./src/global.var
sed -i.back -e '10c\'$'\n integer,dimension('$nchain') ::state' ./src/global.var

make clean
make

###################################################################
#       RUN
###################################################################
time ./bin/3depiblock.link
make clean
